<?php
// Silence is golden. 
// Translation files are placed in this directory.